'use client';

import { useState } from 'react';
import SongsDatabase from '@/components/SongsDatabase/SongsDatabase';
import ClientPortal from '@/components/ClientPortal/ClientPortal';

export default function Home() {
  return <ClientPortal />;
}