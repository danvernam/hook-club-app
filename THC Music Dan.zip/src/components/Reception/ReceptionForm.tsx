'use client';

import { useState, useMemo, useEffect } from 'react';
import Image from 'next/image';

type SongPreference = 'definitely' | 'maybe' | 'avoid' | '';

interface Song {
  song: string;
  artist: string;
  videoUrl: string;
}

interface SetlistSong extends Song {
  key: string;
  leadVocalist: string;
  backupVocalists: string[];
  notes: string;
  originalKey: string;
}

interface SongsDatabase {
  pop: Song[];
  soul: Song[];
  rock: Song[];
  hiphop: Song[];
  disco: Song[];
  instantmosh: Song[];
  country: Song[];
  latin: Song[];
  slowjams: Song[];
}

interface SpecialMoment {
  id: number;
  type: string;
  song: string;
  artist: string;
  videoUrl: string;
  notes: string;
}

const VOCALISTS = ['Ryan', 'Dan', 'Jesse', 'Bree', "L'Marco", 'Lucy', 'Tre'];
const KEYS = ['C', 'Db', 'D', 'Eb', 'E', 'F', 'F#', 'G', 'Ab', 'A', 'Bb', 'B', 'Am', 'Bbm', 'Bm', 'Cm', 'C#m', 'Dm', 'Ebm', 'Em', 'Fm', 'F#m', 'Gm'];

const SPECIAL_MOMENT_TYPES = [
  'Grand Entrance',
  'First Dance',
  'Parent Dance',
  'Cake Cutting',
  'Last Song',
  'Horah',
  'Mezinka Dance',
  'Anniversary Dance',
  'Bouquet Toss',
  'Garter Toss',
  'Other'
];

const SONG_SUGGESTIONS = {
  grandEntrance: [
    { song: "Crazy in Love", artist: "Beyoncé", videoUrl: "https://www.youtube.com/watch?v=ViwtNLUqkMY" },
    { song: "Uptown Funk", artist: "Bruno Mars", videoUrl: "https://www.youtube.com/watch?v=OPf0YbXqDm0" },
    { song: "24K Magic", artist: "Bruno Mars", videoUrl: "https://www.youtube.com/watch?v=UqyT8IEBkvY" },
    { song: "Let's Get It Started", artist: "Black Eyed Peas", videoUrl: "https://www.youtube.com/watch?v=IKqV7DB8Iwg" },
    { song: "All I Do Is Win", artist: "DJ Khaled", videoUrl: "https://www.youtube.com/watch?v=GGXzlRoNtHU" },
    { song: "Can't Stop The Feeling", artist: "Justin Timberlake", videoUrl: "https://www.youtube.com/watch?v=ru0K8uYEZWw" },
    { song: "Happy", artist: "Pharrell Williams", videoUrl: "https://www.youtube.com/watch?v=ZbZSe6N_BXs" },
    { song: "Celebration", artist: "Kool & The Gang", videoUrl: "https://www.youtube.com/watch?v=3GwjfUFyY6M" },
    { song: "September", artist: "Earth, Wind & Fire", videoUrl: "https://www.youtube.com/watch?v=Gs069dndIYk" },
    { song: "Levitating", artist: "Dua Lipa", videoUrl: "https://www.youtube.com/watch?v=TUVcZfQe-Kw" }
  ],
  firstDance: [
    { song: "Perfect", artist: "Ed Sheeran", videoUrl: "https://www.youtube.com/watch?v=2Vv-BfVoq4g" },
    { song: "Thinking Out Loud", artist: "Ed Sheeran", videoUrl: "https://www.youtube.com/watch?v=lp-EO5I60KA" },
    { song: "At Last", artist: "Etta James", videoUrl: "https://www.youtube.com/watch?v=S-cbOl96RFM" },
    { song: "All of Me", artist: "John Legend", videoUrl: "https://www.youtube.com/watch?v=450p7goxZqg" },
    { song: "A Thousand Years", artist: "Christina Perri", videoUrl: "https://www.youtube.com/watch?v=rtOvBOTyX00" },
    { song: "Make You Feel My Love", artist: "Adele", videoUrl: "https://www.youtube.com/watch?v=0put0_a--Ng" },
    { song: "Marry You", artist: "Bruno Mars", videoUrl: "https://www.youtube.com/watch?v=Jbql5eA1dqw" },
    { song: "Everything", artist: "Michael Bublé", videoUrl: "https://www.youtube.com/watch?v=SPUJIbXN0WY" },
    { song: "Can't Help Falling in Love", artist: "Elvis Presley", videoUrl: "https://www.youtube.com/watch?v=vGJTaP6anOU" },
    { song: "Lover", artist: "Taylor Swift", videoUrl: "https://www.youtube.com/watch?v=cvATBaL-91k" }
  ],
  parentDance: [
    { song: "What A Wonderful World", artist: "Louis Armstrong", videoUrl: "https://www.youtube.com/watch?v=VqhCQZaH4Vs" },
    { song: "Isn't She Lovely", artist: "Stevie Wonder", videoUrl: "https://www.youtube.com/watch?v=IVvkjuEAwgU" },
    { song: "My Girl", artist: "The Temptations", videoUrl: "https://www.youtube.com/watch?v=C_CSjcm-z1w" },
    { song: "Stand By Me", artist: "Ben E. King", videoUrl: "https://www.youtube.com/watch?v=hwZNL7QVJjE" },
    { song: "In My Life", artist: "The Beatles", videoUrl: "https://www.youtube.com/watch?v=YBcdt6DsLQA" },
    { song: "Unforgettable", artist: "Nat King Cole", videoUrl: "https://www.youtube.com/watch?v=vDN5rG3wLa4" },
    { song: "The Way You Look Tonight", artist: "Frank Sinatra", videoUrl: "https://www.youtube.com/watch?v=h9ZGKALMMuc" },
    { song: "You Are The Sunshine Of My Life", artist: "Stevie Wonder", videoUrl: "https://www.youtube.com/watch?v=6O8fwUfN8wQ" },
    { song: "Butterfly Kisses", artist: "Bob Carlisle", videoUrl: "https://www.youtube.com/watch?v=vmC3rRR95GA" },
    { song: "Forever Young", artist: "Rod Stewart", videoUrl: "https://www.youtube.com/watch?v=t5qURKt4maw" }
  ],
  cakeCutting: [
    { song: "Sugar, Sugar", artist: "The Archies", videoUrl: "https://www.youtube.com/watch?v=h9nE2spOw_o" },
    { song: "How Sweet It Is", artist: "James Taylor", videoUrl: "https://www.youtube.com/watch?v=29JvbBcJv3w" },
    { song: "Pour Some Sugar On Me", artist: "Def Leppard", videoUrl: "https://www.youtube.com/watch?v=0UIB9Y4OFPs" },
    { song: "Cake By The Ocean", artist: "DNCE", videoUrl: "https://www.youtube.com/watch?v=PAzH-YAlFYc" },
    { song: "Honey, Honey", artist: "ABBA", videoUrl: "https://www.youtube.com/watch?v=4P3L7BwGt9o" },
    { song: "Sugar", artist: "Maroon 5", videoUrl: "https://www.youtube.com/watch?v=09R8_2nJtjg" },
    { song: "Sweet Thing", artist: "Chaka Khan", videoUrl: "https://www.youtube.com/watch?v=0DhRXGNg4Ro" },
    { song: "Sugartown", artist: "Nancy Sinatra", videoUrl: "https://www.youtube.com/watch?v=7Hd0MxsaZxU" }
  ],
  lastSong: [
    { song: "Don't Stop Believin'", artist: "Journey", videoUrl: "https://www.youtube.com/watch?v=1k8craCGpgs" },
    { song: "Livin' On A Prayer", artist: "Bon Jovi", videoUrl: "https://www.youtube.com/watch?v=lDK9QqIzhwk" },
    { song: "Sweet Caroline", artist: "Neil Diamond", videoUrl: "https://www.youtube.com/watch?v=1vhFnTjia_I" },
    { song: "Shut Up And Dance", artist: "Walk The Moon", videoUrl: "https://www.youtube.com/watch?v=6JCLY0Rlx6Q" },
    { song: "Closing Time", artist: "Semisonic", videoUrl: "https://www.youtube.com/watch?v=xGytDsqkQY8" },
    { song: "All Star", artist: "Smash Mouth", videoUrl: "https://www.youtube.com/watch?v=L_jWHffIx5E" },
    { song: "Mr. Brightside", artist: "The Killers", videoUrl: "https://www.youtube.com/watch?v=gGdGFtwCNBE" },
    { song: "I Wanna Dance With Somebody", artist: "Whitney Houston", videoUrl: "https://www.youtube.com/watch?v=eH3giaIzONA" }
  ]
};

const GENRE_TITLES: Record<string, string> = {
  pop: "Cream Of The Pop",
  soul: "Souled Out",
  rock: "Rock Solid",
  hiphop: "Hip-Hop Hits",
  disco: "Disco Inferno",
  instantmosh: "Instant Mosh",
  country: "Country Classics",
  latin: "Latin Fuego",
  slowjams: "Slow Jams"
};

export default function ReceptionForm() {
  const [mainTab, setMainTab] = useState<'general' | 'ceremony' | 'cocktail' | 'reception' | 'afterparty'>('general');
  const [showBandPrep, setShowBandPrep] = useState(false);
  const [receptionTab, setReceptionTab] = useState<'special' | 'requests' | 'songlist'>('special');
  const [bandPrepTab, setBandPrepTab] = useState<'selection' | 'setlist'>('selection');
  const [preferences, setPreferences] = useState<Record<string, SongPreference>>({});
  const [selectedForSetlist, setSelectedForSetlist] = useState<Set<string>>(new Set());
  const [setlistSongs, setSetlistSongs] = useState<SetlistSong[]>([]);
  const [specialMoments, setSpecialMoments] = useState<SpecialMoment[]>([]);
  const [songsData, setSongsData] = useState<SongsDatabase | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedGenres, setExpandedGenres] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetch('/data/songs.json')
      .then(res => res.json())
      .then(data => {
        setSongsData(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error loading songs:', err);
        setLoading(false);
      });
  }, []);

  const songCounts = useMemo(() => {
    const counts = { definitely: 0, maybe: 0, avoid: 0 };
    Object.values(preferences).forEach(pref => {
      if (pref === 'definitely') counts.definitely++;
      if (pref === 'maybe') counts.maybe++;
      if (pref === 'avoid') counts.avoid++;
    });
    return counts;
  }, [preferences]);

  const togglePreference = (key: string, pref: SongPreference) => {
    setPreferences(prev => ({
      ...prev,
      [key]: prev[key] === pref ? '' : pref
    }));
  };

  const toggleGenre = (genre: string) => {
    setExpandedGenres(prev => {
      const newSet = new Set(prev);
      if (newSet.has(genre)) {
        newSet.delete(genre);
      } else {
        newSet.add(genre);
      }
      return newSet;
    });
  };

  const addSpecialMoment = () => {
    setSpecialMoments([...specialMoments, {
      id: Date.now(),
      type: '',
      song: '',
      artist: '',
      videoUrl: '',
      notes: ''
    }]);
  };

  const updateSpecialMoment = (id: number, field: keyof SpecialMoment, value: string) => {
    setSpecialMoments(prev => prev.map(moment => 
      moment.id === id ? { ...moment, [field]: value } : moment
    ));
  };

  const selectPopularSong = (id: number, song: { song: string; artist: string; videoUrl: string }) => {
    setSpecialMoments(prev => prev.map(moment =>
      moment.id === id ? { ...moment, song: song.song, artist: song.artist, videoUrl: song.videoUrl } : moment
    ));
  };

  const removeSpecialMoment = (id: number) => {
    setSpecialMoments(prev => prev.filter(moment => moment.id !== id));
  };

  const SongRow = ({ song, artist, videoUrl, prefKey }: { song: string; artist: string; videoUrl: string; prefKey: string }) => (
    <div className="flex items-center justify-between p-2 border border-gray-200 rounded hover:bg-gray-50">
      <div className="flex-1 min-w-0">
        <a href={videoUrl} target="_blank" rel="noopener noreferrer" className="font-semibold text-purple-600 hover:text-purple-800 transition-colors text-sm underline">
          {song}
        </a>
        <span className="text-gray-600 text-sm"> • {artist}</span>
      </div>
      <div className="flex gap-2 ml-2">
        <button
          onClick={(e) => {
            e.preventDefault();
            togglePreference(prefKey, 'definitely');
          }}
          className={`px-3 py-1 text-xs border-2 rounded transition-all ${
            preferences[prefKey] === 'definitely' 
              ? 'border-green-500 bg-green-50 text-green-700' 
              : 'border-gray-300 hover:border-green-500 text-gray-600'
          }`}
        >
          Definitely Play!
        </button>
        <button
          onClick={(e) => {
            e.preventDefault();
            togglePreference(prefKey, 'maybe');
          }}
          className={`px-3 py-1 text-xs border-2 rounded transition-all ${
            preferences[prefKey] === 'maybe' 
              ? 'border-yellow-500 bg-yellow-50 text-yellow-700' 
              : 'border-gray-300 hover:border-yellow-500 text-gray-600'
          }`}
        >
          If The Mood Is Right..
        </button>
        <button
          onClick={(e) => {
            e.preventDefault();
            togglePreference(prefKey, 'avoid');
          }}
          className={`px-3 py-1 text-xs border-2 rounded transition-all ${
            preferences[prefKey] === 'avoid' 
              ? 'border-red-500 bg-red-50 text-red-700' 
              : 'border-gray-300 hover:border-red-500 text-gray-600'
          }`}
        >
          Avoid Playing
        </button>
      </div>
    </div>
  );

  const PopularSongCard = ({ song, artist, videoUrl, onSelect }: { song: string; artist: string; videoUrl: string; onSelect: () => void }) => (
    <div className="bg-white border-2 border-gray-300 rounded p-3 hover:border-purple-500 transition-all">
      <a href={videoUrl} target="_blank" rel="noopener noreferrer" className="block mb-2">
        <div className="font-semibold text-purple-600 hover:text-purple-800 text-sm">{song}</div>
        <div className="text-gray-600 text-xs">{artist}</div>
      </a>
      <button
        onClick={onSelect}
        className="w-full px-3 py-1 bg-purple-600 text-white text-xs rounded hover:bg-purple-700 transition-all"
      >
        Select This Song
      </button>
    </div>
  );

  const SpecialMomentForm = ({ moment }: { moment: SpecialMoment }) => {
    const getSuggestions = () => {
      const type = moment.type.toLowerCase().replace(/\s+/g, '');
      if (type.includes('entrance')) return SONG_SUGGESTIONS.grandEntrance;
      if (type.includes('first')) return SONG_SUGGESTIONS.firstDance;
      if (type.includes('parent')) return SONG_SUGGESTIONS.parentDance;
      if (type.includes('cake')) return SONG_SUGGESTIONS.cakeCutting;
      if (type.includes('last')) return SONG_SUGGESTIONS.lastSong;
      return [];
    };

    const suggestions = getSuggestions();

    return (
      <div className="bg-white p-4 rounded border-2 border-blue-200">
        <div className="flex justify-between items-start mb-3">
          <select
            value={moment.type}
            onChange={(e) => updateSpecialMoment(moment.id, 'type', e.target.value)}
            className="flex-1 p-2 border-2 border-gray-300 rounded text-sm"
          >
            <option value="">Select moment type...</option>
            {SPECIAL_MOMENT_TYPES.map(type => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
          <button
            onClick={() => removeSpecialMoment(moment.id)}
            className="ml-2 px-2 py-1 bg-red-100 text-red-700 rounded text-xs hover:bg-red-200"
          >
            Remove
          </button>
        </div>

        {suggestions.length > 0 && (
          <div className="mb-3">
            <div className="text-xs font-semibold text-gray-700 mb-2">💡 Popular Selections - Click to watch, select to use:</div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 max-h-64 overflow-y-auto p-2 bg-gray-50 rounded">
              {suggestions.map((s, i) => (
                <PopularSongCard
                  key={i}
                  song={s.song}
                  artist={s.artist}
                  videoUrl={s.videoUrl}
                  onSelect={() => selectPopularSong(moment.id, s)}
                />
              ))}
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-2 mb-2">
          <input
            type="text"
            placeholder="Song"
            value={moment.song}
            onChange={(e) => updateSpecialMoment(moment.id, 'song', e.target.value)}
            className="w-full p-2 border-2 border-gray-300 rounded text-sm"
          />
          <input
            type="text"
            placeholder="Artist"
            value={moment.artist}
            onChange={(e) => updateSpecialMoment(moment.id, 'artist', e.target.value)}
            className="w-full p-2 border-2 border-gray-300 rounded text-sm"
          />
        </div>
        <input
          type="url"
          placeholder="Spotify/YouTube Link (optional)"
          value={moment.videoUrl}
          onChange={(e) => updateSpecialMoment(moment.id, 'videoUrl', e.target.value)}
          className="w-full p-2 border-2 border-gray-300 rounded mb-2 text-sm"
        />
        <textarea
          rows={2}
          placeholder="Notes"
          value={moment.notes}
          onChange={(e) => updateSpecialMoment(moment.id, 'notes', e.target.value)}
          className="w-full p-2 border-2 border-gray-300 rounded text-sm"
        />
      </div>
    );
  };

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto p-8 text-center">
        <div className="text-xl text-gray-600">Loading song library...</div>
      </div>
    );
  }

  if (showBandPrep) {
    return (
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-8 pb-6 border-b-4 border-gray-900">
          <div className="flex justify-center mb-4">
            <Image 
              src="/hook-club-logo.png" 
              alt="The Hook Club" 
              width={300} 
              height={120}
              priority
            />
          </div>
          <p className="text-xl italic text-gray-700">Music Planning Worksheet</p>
          <p className="text-gray-600 mt-2">Harry Truman & Sally Fields • Wedding</p>
          <p className="text-gray-600 font-semibold">Saturday 9/27/25 • The Greenpoint Loft</p>
        </div>

        <button
          onClick={() => setShowBandPrep(false)}
          className="mb-6 px-6 py-3 bg-gray-600 text-white rounded font-semibold hover:bg-gray-700"
        >
          ← Back to Event Details
        </button>

        <div className="bg-white border-2 border-gray-300 rounded-lg shadow-lg p-8">
          <div className="border-l-4 border-black pl-4 mb-6">
            <h2 className="text-3xl font-bold text-black">Band Prep</h2>
          </div>

          <div className="mb-6">
            <div className="bg-gray-100 p-2 rounded-lg">
              <div className="flex gap-2">
                <button
                  onClick={() => setBandPrepTab('selection')}
                  className={`flex-1 px-4 py-2 font-semibold rounded transition-all ${
                    bandPrepTab === 'selection' 
                      ? 'bg-white text-black' 
                      : 'bg-transparent text-gray-700 hover:bg-white'
                  }`}
                >
                  Song Selection
                </button>
                <button
                  onClick={() => setBandPrepTab('setlist')}
                  className={`flex-1 px-4 py-2 font-semibold rounded transition-all ${
                    bandPrepTab === 'setlist' 
                      ? 'bg-white text-black' 
                      : 'bg-transparent text-gray-700 hover:bg-white'
                  }`}
                >
                  Setlist Builder ({setlistSongs.length})
                </button>
              </div>
            </div>
          </div>

          {bandPrepTab === 'selection' && (
            <>
              <div className="mb-6 p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
                <h3 className="text-lg font-bold text-black mb-2">Client Preferences Summary</h3>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="bg-green-50 border border-green-500 rounded p-2">
                    <div className="text-xl font-bold text-green-700">{songCounts.definitely}</div>
                    <div className="text-xs text-gray-700">Definitely Play!</div>
                  </div>
                  <div className="bg-yellow-50 border border-yellow-500 rounded p-2">
                    <div className="text-xl font-bold text-yellow-700">{songCounts.maybe}</div>
                    <div className="text-xs text-gray-700">If Mood Is Right</div>
                  </div>
                  <div className="bg-purple-50 border border-purple-500 rounded p-2">
                    <div className="text-xl font-bold text-purple-700">{selectedForSetlist.size}</div>
                    <div className="text-xs text-gray-700">Selected</div>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="p-4 bg-green-50 rounded-lg border-2 border-green-500">
                  <h3 className="text-lg font-bold text-black mb-4">Definitely Play! (Priority Songs)</h3>
                  {Object.entries(preferences)
                    .filter(([_, pref]) => pref === 'definitely')
                    .length === 0 ? (
                    <p className="text-gray-600 italic">No songs marked as "Definitely Play!" yet</p>
                  ) : (
                    <div className="space-y-2">
                      {Object.entries(preferences)
                        .filter(([_, pref]) => pref === 'definitely')
                        .map(([key]) => {
                          const [genre, index] = key.split('-');
                          const song = songsData?.[genre as keyof SongsDatabase]?.[parseInt(index)];
                          if (!song) return null;
                          
                          const isSelected = selectedForSetlist.has(key);
                          
                          return (
                            <div key={key} className="flex items-center justify-between p-3 bg-white border border-green-200 rounded">
                              <div className="flex-1">
                                <div className="font-semibold text-black">{song.song}</div>
                                <div className="text-sm text-gray-600">{song.artist}</div>
                              </div>
                              <button
                                onClick={() => {
                                  const newSet = new Set(selectedForSetlist);
                                  if (isSelected) {
                                    newSet.delete(key);
                                    setSetlistSongs(prev => prev.filter(s => s.originalKey !== key));
                                  } else {
                                    newSet.add(key);
                                    setSetlistSongs(prev => [...prev, {
                                      ...song,
                                      originalKey: key,
                                      key: '',
                                      leadVocalist: '',
                                      backupVocalists: [],
                                      notes: ''
                                    }]);
                                  }
                                  setSelectedForSetlist(newSet);
                                }}
                                className={`px-4 py-2 rounded font-semibold transition-all ${
                                  isSelected
                                    ? 'bg-purple-600 text-white hover:bg-purple-700'
                                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                }`}
                              >
                                {isSelected ? '✓ In Setlist' : 'Add to Setlist'}
                              </button>
                            </div>
                          );
                        })}
                    </div>
                  )}
                </div>

                <div className="p-4 bg-yellow-50 rounded-lg border-2 border-yellow-500">
                  <h3 className="text-lg font-bold text-black mb-4">If The Mood Is Right.. (Optional Songs)</h3>
                  {Object.entries(preferences)
                    .filter(([_, pref]) => pref === 'maybe')
                    .length === 0 ? (
                    <p className="text-gray-600 italic">No songs marked as "If The Mood Is Right.." yet</p>
                  ) : (
                    <div className="space-y-2">
                      {Object.entries(preferences)
                        .filter(([_, pref]) => pref === 'maybe')
                        .map(([key]) => {
                          const [genre, index] = key.split('-');
                          const song = songsData?.[genre as keyof SongsDatabase]?.[parseInt(index)];
                          if (!song) return null;
                          
                          const isSelected = selectedForSetlist.has(key);
                          
                          return (
                            <div key={key} className="flex items-center justify-between p-3 bg-white border border-yellow-200 rounded">
                              <div className="flex-1">
                                <div className="font-semibold text-black">{song.song}</div>
                                <div className="text-sm text-gray-600">{song.artist}</div>
                              </div>
                              <button
                                onClick={() => {
                                  const newSet = new Set(selectedForSetlist);
                                  if (isSelected) {
                                    newSet.delete(key);
                                    setSetlistSongs(prev => prev.filter(s => s.originalKey !== key));
                                  } else {
                                    newSet.add(key);
                                    setSetlistSongs(prev => [...prev, {
                                      ...song,
                                      originalKey: key,
                                      key: '',
                                      leadVocalist: '',
                                      backupVocalists: [],
                                      notes: ''
                                    }]);
                                  }
                                  setSelectedForSetlist(newSet);
                                }}
                                className={`px-4 py-2 rounded font-semibold transition-all ${
                                  isSelected
                                    ? 'bg-purple-600 text-white hover:bg-purple-700'
                                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                }`}
                              >
                                {isSelected ? '✓ In Setlist' : 'Add to Setlist'}
                              </button>
                            </div>
                          );
                        })}
                    </div>
                  )}
                </div>

                <div className="p-4 bg-red-50 rounded-lg border-2 border-red-500">
                  <h3 className="text-lg font-bold text-black mb-4">Avoid Playing (Do Not Include)</h3>
                  {Object.entries(preferences)
                    .filter(([_, pref]) => pref === 'avoid')
                    .length === 0 ? (
                    <p className="text-gray-600 italic">No songs marked to avoid</p>
                  ) : (
                    <div className="space-y-2">
                      {Object.entries(preferences)
                        .filter(([_, pref]) => pref === 'avoid')
                        .map(([key]) => {
                          const [genre, index] = key.split('-');
                          const song = songsData?.[genre as keyof SongsDatabase]?.[parseInt(index)];
                          if (!song) return null;
                          
                          return (
                            <div key={key} className="flex items-center p-3 bg-white border border-red-200 rounded opacity-60">
                              <div className="flex-1">
                                <div className="font-semibold text-black line-through">{song.song}</div>
                                <div className="text-sm text-gray-600">{song.artist}</div>
                              </div>
                              <span className="text-red-600 font-semibold text-sm">DO NOT PLAY</span>
                            </div>
                          );
                        })}
                    </div>
                  )}
                </div>
              </div>

              {selectedForSetlist.size > 0 && (
                <div className="mt-6 p-4 bg-purple-50 border-2 border-purple-500 rounded-lg">
                  <h3 className="text-lg font-bold text-black mb-3">Ready to Build Setlist</h3>
                  <p className="text-gray-700 mb-3">
                    You've selected <strong>{selectedForSetlist.size} songs</strong>. Click the Setlist Builder tab to arrange them and assign vocalists.
                  </p>
                </div>
              )}
            </>
          )}

          {bandPrepTab === 'setlist' && (
            <>
              {setlistSongs.length === 0 ? (
                <div className="p-8 text-center border-2 border-dashed border-gray-300 rounded-lg">
                  <p className="text-gray-600 text-lg mb-2">No songs in setlist yet</p>
                  <p className="text-gray-500 text-sm">Go to Song Selection tab to add songs</p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="p-4 bg-gray-100 rounded-lg border-2 border-gray-300">
                    <h3 className="text-lg font-bold text-black mb-2">Setlist Overview</h3>
                    <div className="text-sm text-gray-700">
                      <strong>{setlistSongs.length} songs</strong> selected
                    </div>
                  </div>

                  <div className="space-y-3">
                    {setlistSongs.map((song, index) => (
                      <div key={index} className="p-4 bg-white border-2 border-gray-300 rounded-lg">
                        <div className="flex items-start gap-4">
                          <div className="flex flex-col gap-2">
                            <button
                              onClick={() => {
                                if (index === 0) return;
                                const newList = [...setlistSongs];
                                [newList[index - 1], newList[index]] = [newList[index], newList[index - 1]];
                                setSetlistSongs(newList);
                              }}
                              disabled={index === 0}
                              className="px-2 py-1 bg-gray-200 rounded text-xs disabled:opacity-30"
                            >
                              ↑
                            </button>
                            <div className="text-center font-bold text-gray-700">#{index + 1}</div>
                            <button
                              onClick={() => {
                                if (index === setlistSongs.length - 1) return;
                                const newList = [...setlistSongs];
                                [newList[index + 1], newList[index]] = [newList[index], newList[index + 1]];
                                setSetlistSongs(newList);
                              }}
                              disabled={index === setlistSongs.length - 1}
                              className="px-2 py-1 bg-gray-200 rounded text-xs disabled:opacity-30"
                            >
                              ↓
                            </button>
                          </div>

                          <div className="flex-1">
                            <div className="font-bold text-lg text-black mb-1">{song.song}</div>
                            <div className="text-sm text-gray-600 mb-3">{song.artist}</div>

                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="block text-xs font-semibold text-gray-700 mb-1">Key</label>
                                <select
                                  value={song.key}
                                  onChange={(e) => {
                                    const newList = [...setlistSongs];
                                    newList[index].key = e.target.value;
                                    setSetlistSongs(newList);
                                  }}
                                  className="w-full p-2 border-2 border-gray-300 rounded text-sm"
                                >
                                  <option value="">Select key...</option>
                                  {KEYS.map(k => (
                                    <option key={k} value={k}>{k}</option>
                                  ))}
                                </select>
                              </div>

                              <div>
                                <label className="block text-xs font-semibold text-gray-700 mb-1">Lead Vocalist</label>
                                <select
                                  value={song.leadVocalist}
                                  onChange={(e) => {
                                    const newList = [...setlistSongs];
                                    newList[index].leadVocalist = e.target.value;
                                    setSetlistSongs(newList);
                                  }}
                                  className="w-full p-2 border-2 border-gray-300 rounded text-sm"
                                >
                                  <option value="">Select vocalist...</option>
                                  {VOCALISTS.map(v => (
                                    <option key={v} value={v}>{v}</option>
                                  ))}
                                </select>
                              </div>
                            </div>

                            <div className="mt-3">
                              <label className="block text-xs font-semibold text-gray-700 mb-1">Notes / Arrangement</label>
                              <textarea
                                value={song.notes}
                                onChange={(e) => {
                                  const newList = [...setlistSongs];
                                  newList[index].notes = e.target.value;
                                  setSetlistSongs(newList);
                                }}
                                placeholder="Transitions, breakdowns, special instructions..."
                                className="w-full p-2 border-2 border-gray-300 rounded text-sm"
                                rows={2}
                              />
                            </div>
                          </div>

                          <button
                            onClick={() => {
                              const newList = setlistSongs.filter((_, i) => i !== index);
                              setSetlistSongs(newList);
                              selectedForSetlist.delete(song.originalKey);
                              setSelectedForSetlist(new Set(selectedForSetlist));
                            }}
                            className="px-3 py-1 bg-red-100 text-red-700 rounded hover:bg-red-200 text-sm font-semibold"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 p-4 bg-blue-50 border-2 border-blue-200 rounded-lg">
                    <h3 className="text-lg font-bold text-black mb-2">Export Setlist</h3>
                    <button className="px-6 py-3 bg-blue-600 text-white rounded font-semibold hover:bg-blue-700">
                      Print/Export Setlist
                    </button>
                    <p className="text-sm text-gray-600 mt-2 italic">Coming soon: Print-ready setlist with all details</p>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto">
      <div className="text-center mb-8 pb-6 border-b-4 border-gray-900">
        <div className="flex justify-center mb-4">
          <Image 
            src="/hook-club-logo.png" 
            alt="The Hook Club" 
            width={300} 
            height={120}
            priority
          />
        </div>
        <p className="text-xl italic text-gray-700">Music Planning Worksheet</p>
        <p className="text-gray-600 mt-2">Harry Truman & Sally Fields • Wedding</p>
        <p className="text-gray-600 font-semibold">Saturday 9/27/25 • The Greenpoint Loft</p>
      </div>

      <div className="mb-6 flex gap-4">
        <div className="flex-1 bg-gray-200 p-2 rounded-lg">
          <div className="flex gap-2">
            <button
              onClick={() => setMainTab('general')}
              className={`flex-1 px-4 py-2 font-semibold rounded transition-all ${
                mainTab === 'general' 
                  ? 'bg-white text-black' 
                  : 'bg-transparent text-gray-700 hover:bg-white'
              }`}
            >
              General Info
            </button>
            <button
              onClick={() => setMainTab('ceremony')}
              className={`flex-1 px-4 py-2 font-semibold rounded transition-all ${
                mainTab === 'ceremony' 
                  ? 'bg-white text-black' 
                  : 'bg-transparent text-gray-700 hover:bg-white'
              }`}
            >
              Ceremony
            </button>
            <button
              onClick={() => setMainTab('cocktail')}
              className={`flex-1 px-4 py-2 font-semibold rounded transition-all ${
                mainTab === 'cocktail' 
                  ? 'bg-white text-black' 
                  : 'bg-transparent text-gray-700 hover:bg-white'
              }`}
            >
              Cocktail Hour
            </button>
            <button
              onClick={() => setMainTab('reception')}
              className={`flex-1 px-4 py-2 font-semibold rounded transition-all ${
                mainTab === 'reception' 
                  ? 'bg-white text-black' 
                  : 'bg-transparent text-gray-700 hover:bg-white'
              }`}
            >
              Reception
            </button>
            <button
              onClick={() => setMainTab('afterparty')}
              className={`flex-1 px-4 py-2 font-semibold rounded transition-all ${
                mainTab === 'afterparty' 
                  ? 'bg-white text-black' 
                  : 'bg-transparent text-gray-700 hover:bg-white'
              }`}
            >
              After-Party
            </button>
          </div>
        </div>
        <button
          onClick={() => setShowBandPrep(true)}
          className="px-6 py-2 bg-purple-600 text-white font-semibold rounded hover:bg-purple-700 transition-all"
        >
          Band Prep →
        </button>
      </div>

      {mainTab === 'general' && (
        <div className="bg-white border-2 border-gray-300 rounded-lg shadow-lg p-8">
          <div className="border-l-4 border-black pl-4 mb-6">
            <h2 className="text-3xl font-bold text-black">General Info</h2>
          </div>

          <div className="mb-8 p-5 bg-purple-50 rounded-lg border-2 border-purple-200">
            <h3 className="text-xl font-bold text-black mb-4">Your Ensembles</h3>
            
            <div className="space-y-4">
              <div className="bg-white p-4 rounded">
                <label className="block text-sm font-bold text-black mb-2">Ceremony</label>
                <input 
                  type="text" 
                  value="Solo Piano"
                  className="w-full p-2 border-2 border-gray-300 rounded text-gray-700 bg-gray-50"
                  readOnly
                />
              </div>

              <div className="bg-white p-4 rounded">
                <label className="block text-sm font-bold text-black mb-2">Cocktail Hour</label>
                <input 
                  type="text" 
                  value="Jazzy Duo (Sax + Guitar)"
                  className="w-full p-2 border-2 border-gray-300 rounded text-gray-700 bg-gray-50"
                  readOnly
                />
              </div>

              <div className="bg-white p-4 rounded">
                <label className="block text-sm font-bold text-black mb-2">Reception</label>
                <input 
                  type="text" 
                  value="8-Piece Classic Band (3 Vocalists + Sax + Guitar + Keyboard + Bass + Drums)"
                  className="w-full p-2 border-2 border-gray-300 rounded text-gray-700 bg-gray-50"
                  readOnly
                />
              </div>
            </div>
          </div>

          <div className="p-5 bg-blue-50 rounded-lg border-2 border-blue-200">
            <h3 className="text-xl font-bold text-black mb-4">Getting to Know You</h3>
            
            <div className="space-y-4">
              <div className="bg-white p-4 rounded">
                <label className="block text-sm font-bold text-black mb-2">How did you two meet?</label>
                <textarea 
                  rows={3} 
                  placeholder="Tell us your story..."
                  className="w-full p-2 border-2 border-gray-300 rounded text-gray-700 placeholder:text-gray-400"
                />
              </div>

              <div className="bg-white p-4 rounded">
                <label className="block text-sm font-bold text-black mb-2">What's your vision for the vibe/energy of your wedding?</label>
                <textarea 
                  rows={3} 
                  placeholder="Elegant and romantic? High energy dance party? Laid back celebration?"
                  className="w-full p-2 border-2 border-gray-300 rounded text-gray-700 placeholder:text-gray-400"
                />
              </div>

              <div className="bg-white p-4 rounded">
                <label className="block text-sm font-bold text-black mb-2">Are there any special moments or traditions we should know about?</label>
                <textarea 
                  rows={3} 
                  placeholder="Cultural traditions, family customs, surprise performances, etc."
                  className="w-full p-2 border-2 border-gray-300 rounded text-gray-700 placeholder:text-gray-400"
                />
              </div>

              <div className="bg-white p-4 rounded">
                <label className="block text-sm font-bold text-black mb-2">Anything else you'd like us to know?</label>
                <textarea 
                  rows={3} 
                  placeholder="Special requests, concerns, or anything else on your mind..."
                  className="w-full p-2 border-2 border-gray-300 rounded text-gray-700 placeholder:text-gray-400"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {mainTab === 'ceremony' && (
        <div className="bg-white border-2 border-gray-300 rounded-lg shadow-lg p-8">
          <div className="border-l-4 border-black pl-4 mb-6">
            <h2 className="text-3xl font-bold text-black">Ceremony</h2>
            <p className="text-gray-600 mt-2">Solo Piano</p>
          </div>
          <p className="text-gray-600 italic">Ceremony music options coming soon...</p>
        </div>
      )}

      {mainTab === 'cocktail' && (
        <div className="bg-white border-2 border-gray-300 rounded-lg shadow-lg p-8">
          <div className="border-l-4 border-black pl-4 mb-6">
            <h2 className="text-3xl font-bold text-black">Cocktail Hour</h2>
            <p className="text-gray-600 mt-2">Jazzy Duo (Sax + Guitar)</p>
          </div>
          <p className="text-gray-600 italic">Cocktail hour music options coming soon...</p>
        </div>
      )}

      {mainTab === 'afterparty' && (
        <div className="bg-white border-2 border-gray-300 rounded-lg shadow-lg p-8">
          <div className="border-l-4 border-black pl-4 mb-6">
            <h2 className="text-3xl font-bold text-black">After-Party</h2>
          </div>
          <p className="text-gray-600 italic">After-party music options coming soon...</p>
        </div>
      )}

      {mainTab === 'reception' && (
        <>
          <div className="mb-6">
            <div className="bg-gray-100 p-2 rounded-lg">
              <div className="flex gap-2">
                <button
                  onClick={() => setReceptionTab('special')}
                  className={`flex-1 px-4 py-2 font-semibold rounded transition-all ${
                    receptionTab === 'special' 
                      ? 'bg-white text-black' 
                      : 'bg-transparent text-gray-700 hover:bg-white'
                  }`}
                >
                  Special Moments
                </button>
                <button
                  onClick={() => setReceptionTab('requests')}
                  className={`flex-1 px-4 py-2 font-semibold rounded transition-all ${
                    receptionTab === 'requests' 
                      ? 'bg-white text-black' 
                      : 'bg-transparent text-gray-700 hover:bg-white'
                  }`}
                >
                  Song Requests
                </button>
                <button
                  onClick={() => setReceptionTab('songlist')}
                  className={`flex-1 px-4 py-2 font-semibold rounded transition-all ${
                    receptionTab === 'songlist' 
                      ? 'bg-white text-black' 
                      : 'bg-transparent text-gray-700 hover:bg-white'
                  }`}
                >
                  THC Song List
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white border-2 border-gray-300 rounded-lg shadow-lg p-8">
            {receptionTab === 'special' && (
              <>
                <div className="border-l-4 border-black pl-4 mb-6">
                  <h2 className="text-3xl font-bold text-black">Special Moments</h2>
                  <p className="text-gray-600 mt-2">Tell us about the key moments of your reception</p>
                </div>

                <div className="space-y-4">
                  {specialMoments.map(moment => (
                    <SpecialMomentForm key={moment.id} moment={moment} />
                  ))}

                  <button
                    onClick={addSpecialMoment}
                    className="w-full p-3 border-2 border-dashed border-gray-400 rounded text-gray-600 hover:border-black hover:text-black font-semibold"
                  >
                    + Add Special Moment
                  </button>
                </div>
              </>
            )}

            {receptionTab === 'requests' && (
              <>
                <div className="border-l-4 border-black pl-4 mb-6">
                  <h2 className="text-3xl font-bold text-black">Song Requests</h2>
                  <p className="text-gray-600 mt-2">Tell us about songs you'd love to hear</p>
                </div>

                <div className="space-y-6">
                  <div className="p-4 bg-white rounded border-2 border-gray-300">
                    <label className="block text-sm font-bold text-black mb-3">Essential Requests</label>
                    <p className="text-sm text-gray-600 mb-3">Songs that absolutely must be played during your reception</p>
                    <textarea 
                      rows={4} 
                      placeholder="List must-play songs with artist names..."
                      className="w-full p-3 border-2 border-gray-300 rounded text-gray-700 placeholder:text-gray-400"
                    />
                  </div>

                  <div className="p-4 bg-white rounded border-2 border-gray-300">
                    <label className="block text-sm font-bold text-black mb-3">Additional Song Requests</label>
                    <p className="text-sm text-gray-600 mb-3">Other songs you'd enjoy hearing if there's time</p>
                    <textarea 
                      rows={4} 
                      placeholder="List additional song requests..."
                      className="w-full p-3 border-2 border-gray-300 rounded text-gray-700 placeholder:text-gray-400"
                    />
                  </div>

                  <div className="p-4 bg-white rounded border-2 border-gray-300">
                    <label className="block text-sm font-bold text-black mb-3">Do Not Play</label>
                    <p className="text-sm text-gray-600 mb-3">Any songs or artists you definitely don't want to hear?</p>
                    <textarea 
                      rows={4} 
                      placeholder="List any songs or artists to avoid..."
                      className="w-full p-3 border-2 border-gray-300 rounded text-gray-700 placeholder:text-gray-400"
                    />
                  </div>
                </div>
              </>
            )}

            {receptionTab === 'songlist' && songsData && (
              <>
                <div className="border-l-4 border-black pl-4 mb-6">
                  <h2 className="text-3xl font-bold text-black">The Hook Club Song List</h2>
                  <p className="text-gray-600 mt-2">Browse our repertoire and let us know your preferences</p>
                </div>

                <div className="mb-6 p-4 bg-purple-50 rounded-lg border-2 border-purple-200">
                  <h3 className="text-lg font-bold text-black mb-3">Your Selections</h3>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="bg-green-50 border-2 border-green-500 rounded p-3">
                      <div className="text-2xl font-bold text-green-700">{songCounts.definitely}</div>
                      <div className="text-sm text-gray-700">Definitely Play!</div>
                    </div>
                    <div className="bg-yellow-50 border-2 border-yellow-500 rounded p-3">
                      <div className="text-2xl font-bold text-yellow-700">{songCounts.maybe}</div>
                      <div className="text-sm text-gray-700">If Mood Is Right</div>
                    </div>
                    <div className="bg-red-50 border-2 border-red-500 rounded p-3">
                      <div className="text-2xl font-bold text-red-700">{songCounts.avoid}</div>
                      <div className="text-sm text-gray-700">Avoid Playing</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  {Object.entries(songsData).map(([genre, songs]) => (
                    <div key={genre} className="border-2 border-gray-300 rounded-lg overflow-hidden">
                      <button
                        onClick={() => toggleGenre(genre)}
                        className="w-full p-4 bg-gray-100 hover:bg-gray-200 flex items-center justify-between transition-all"
                      >
                        <h3 className="text-xl font-bold text-black">{GENRE_TITLES[genre] || genre}</h3>
                        <span className="text-2xl text-gray-600">
                          {expandedGenres.has(genre) ? '−' : '+'}
                        </span>
                      </button>
                      {expandedGenres.has(genre) && (
                        <div className="p-4 bg-white space-y-2">
                          {songs.map((song, index) => (
                            <SongRow 
                              key={`${genre}-${index}`}
                              song={song.song}
                              artist={song.artist}
                              videoUrl={song.videoUrl}
                              prefKey={`${genre}-${index}`}
                            />
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
}